class Game extends Scene {
    create() {
        this.map = this.game.assetManager.getMap("demo");

        this.map.objects.forEach(function(object) {
            if (object.name === "hero") {
                this.hero = this.createObject(Hero, {position: object.position});
            }
        }, this);

        this.game.camera.setBorder(0, 0, this.map.width * this.map.tileWidth, this.map.height * this.map.tileHeight);
    }

    render(delta) {
        this.game.camera.setTarget(this.hero.position);

        this.map.renderBackLayers();
        //this.map.drawSolid();
       // this.map.drawGrid();
        this.renderAllObjects(delta);
        this.map.renderFrontLayers();
        
        this.game.context.font = "10px Verdana";
        this.game.context.fillStyle = "aqua";
        this.game.context.fillText("fps: " + this.game.fps, 10, 10);
    }
}