class Loader extends Scene {
    create() {
        this.game.assetManager.addMap("demo");
        this.game.assetManager.addPNG("hero");
        this.game.assetManager.addSprite("hero");
        
        this.game.assetManager.load(() => {
            this.game.setScene("game");
        });

        this.game.gui.addBlock("loader");
        this.game.gui.showBlock("loader");
    }

    shutdown() {
        this.game.gui.hideBlock("loader");
    }
}