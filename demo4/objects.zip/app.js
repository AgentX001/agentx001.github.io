let game;

window.onload = () => {
    game = new Engine(document.getElementById("main-cnv"), 800, 600);
    
    game.addScene("loader", Loader);
    game.addScene("game", Game);

    game.setScene("loader");
}