class Hero extends GameObject {
    create() {
        this.setSprite("hero");
        this.setSpriteAnimation("down");
        this.spriteAnimationStop(1);
    }

    render(delta) {
        let speed = 100 * delta;
        let tilePos = this.scene.map.toTilePosition(this.position);

        let nextPos = this.position.copy();

        if (this.game.keyboard.pressed("W".charCodeAt(0))) {
            nextPos.y -= speed;
            this.setSpriteAnimation("up");
            this.spriteAnimationStart();
        } else if (this.game.keyboard.pressed("S".charCodeAt(0))) {
            nextPos.y += speed;
            this.setSpriteAnimation("down");
            this.spriteAnimationStart();
        } else if (this.game.keyboard.pressed("A".charCodeAt(0))) {
            nextPos.x -= speed;
            this.setSpriteAnimation("left");
            this.spriteAnimationStart();
        } else if (this.game.keyboard.pressed("D".charCodeAt(0))) {
            nextPos.x += speed;
            this.setSpriteAnimation("right");
            this.spriteAnimationStart();
        } else {
            this.spriteAnimationStop(1);
        }

        let nextTilePos = this.scene.map.toTilePosition(nextPos);
        if (!this.scene.map.solidMap[nextTilePos.x][nextTilePos.y]) this.position = nextPos;

        /*this.scene.map.drawRect(tilePos);

        this.game.context.fillStyle = "red";
        this.game.context.fillRect(this.position.x - 2, this.position.y - 2, 4, 4);

        this.game.context.font = "10px Verdana";
        this.game.context.fillStyle = "blue";
        this.game.context.fillText("tile_x: " + tilePos.x + " tile_y: " + tilePos.y, 10, 25);*/
    }
}