class Scene {
    constructor(_game) {
        this.game = _game;
        this.objects = [];
    }

    createObject(object, parameters) {
        let o = new object(this.game, this, parameters);
        let id = this.objects.push(o);
        o.id = id;
        return o;
    }

    renderAllObjects(delta) {
        this.objects.forEach(function(object) {
            object._render(delta);
        }, this);
    }

    create() {}
    render(delta) {}
    shutdown() {}
}