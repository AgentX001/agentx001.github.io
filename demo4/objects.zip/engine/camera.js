class Camera {
    constructor(game, width, height) {
        this.game = game;
        this.width = width;
        this.height = height;

        this.midWidth = this.width / 2;
        this.midHeight = this.height / 2;

        this.position = new Vector(width/2, height/2);

        this.topLeftX = this.position.x - this.midWidth;
        this.topLeftY = this.position.y - this.midHeight;

        this._borderX = 0;
        this._borderY = 0;
        this._borderX1 = width;
        this._borderY1 = height;

        this.target = null;
    }

    setBorder(x, y, x1, y1) {
        this._borderX = x;
        this._borderY = y;
        this._borderX1 = x1;
        this._borderY1 = y1;
    }

    setTarget(target) {
        this.target = target;
    }

    render() {
        if (this.target instanceof Vector) {
            this.position = this.target.copy();
        }

        this.position.x = Math.round(this.position.x);
        this.position.y = Math.round(this.position.y);

        if (this.position.x - this.midWidth < this._borderX) this.position.x = this._borderX + this.midWidth;
        if (this.position.x + this.midWidth > this._borderX1) this.position.x = this._borderX1 - this.midWidth;
        if (this.position.y - this.midHeight < this._borderY) this.position.y = this._borderY + this.midHeight;
        if (this.position.y + this.midHeight > this._borderY1) this.position.y = this._borderY1 - this.midHeight;

        this.topLeftX = this.position.x - this.midWidth;
        this.topLeftY = this.position.y - this.midHeight;
    }
}