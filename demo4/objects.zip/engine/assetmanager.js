class AssetManager {
    constructor(game) {
        this.game = game;
        this._assets = [];
        this._assets["maps"] = [];
        this._assets["images"] = [];
        this._assets["sprites"] = [];
    }

    addMap(name) {
        this._assets.maps.push(name);
    }

    getMap(name) {
        return this._assets["maps"][name];
    }

    addPNG(name) {
        this._assets.images.push([name, ".png"]);
    }

    getImage(name) {
        return this._assets["images"][name];
    }

    addSprite(name) {
        this._assets.sprites.push(name);
    }

    getSprite(name) {
        return this._assets["sprites"][name];
    }

    load(callback) {
        this.assetsCount = this._assets.maps.length + this._assets.images.length  + this._assets.sprites.length;
        this.assetsLoaded = 0;
        this.callback = callback;

        this._assets.maps.forEach(function(name) {
            this._assets.maps[name] = new Map(this.game, name, this._onLoaded.bind(this));
        }, this);

        this._assets.images.forEach(function(image) {
            let img = new Image();
            img.src = "./assets/images/" + image[0] + image[1];
            img.onload = this._onLoaded.bind(this);
            this._assets.images[image[0]] = img;
        }, this);

        this._assets.sprites.forEach(function(name) {
            this._assets.sprites[name] = new Sprite(this.game, name, this._onLoaded.bind(this));
        }, this);
    }

    _onLoaded() {
        this.assetsLoaded++;
        if (this.assetsLoaded >= this.assetsCount) this.callback();
    }
}