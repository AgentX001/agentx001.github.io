class Engine {
    constructor(canvas, width, height) {
        this.canvas = canvas;
        this.canvas.width = width;
        this.canvas.height = height;
        this.context = this.canvas.getContext('2d');

        this.lastFrameTime = new Date();

        this.fps = 0;
        this.renderCalls = 0;
        
        this.fpsTimer = setInterval(() => {
            this.fps = this.renderCalls;
            this.renderCalls = 0;
        }, 1000);

        this.scenes = [];
        this.scene = "";

        this.camera = new Camera(this, width, height+10);

        this.assetManager = new AssetManager(this);
        this.keyboard = new Keyboard(this);
        this.mouse = new Mouse(this, this.canvas);
        this.gui = new GUI(this);

        this.reqAnimF = requestAnimationFrame(this._render.bind(this));
        this._render();
    }

    addScene(name, scene) {
        this.scenes[name] = new scene(this);
    }

    setScene(name) {
        if (this.scene !== "") this.scenes[this.scene].shutdown();
        this.scene = name;
        this.scenes[name].create();
    }

    _render() {
        this.renderCalls++;

        let time = new Date(); 
        let delta = (time - this.lastFrameTime) / 1000;
        this.lastFrameTime = time;
        this.lastDelta = delta

        this.context.fillStyle = 'black';
        this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);

        if (this.scene !== "") this.scenes[this.scene].render(delta);
        
        this.camera.render(delta);

        requestAnimationFrame(this._render.bind(this));
    }
}