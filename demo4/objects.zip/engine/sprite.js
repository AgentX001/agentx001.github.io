class Sprite {
    constructor(game, name, callback) {
        this.game = game;
        this.callback = callback;

        this._getData("../assets/sprites/" + name + ".json", (data) => {
            let sprite = JSON.parse(data);
            for (let key in sprite) {
                this[key] = sprite[key];
            }

            this.columns = this.imageWidth / this.frameWidth;
            this.rows = this.imageHeight / this.frameHeight;

            let image = new Image();
            image.src = "../assets/sprites/" + this.image;
            image.onload = this.onImage.bind(this);
            this.image = image;
        });
    }

    onImage() {
        this.callback();
    }

    _getData(url, ready) {
        console.log(url)
        let xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.onreadystatechange = function() {
            if(this.readyState === 4 && this.status !== 404) {
                ready(this.responseText);
            }
        }
        xhr.send();
    }

    render(position, animation, frame) {
        let x = position.x - this.game.camera.topLeftX - this.offsetX;
        let y = position.y - this.game.camera.topLeftY - this.offsetY;
        let realFrame = this.animations[animation][frame];
        let sy = Math.floor(realFrame / this.columns);    
        let sx = realFrame - sy * this.columns;
        sx *= this.frameWidth;
        sy *= this.frameHeight;
        this.game.context.drawImage(this.image, sx, sy, this.frameWidth, this.frameHeight, x, y, this.frameWidth, this.frameHeight);
    }
}