class Map {
    constructor(game, name, handler) {
        this.game = game;

        let path = "./assets/maps/" + name + ".json";

        this._getData(path, ((data) => {
            let map = JSON.parse(data);

            if (map.type !== "map") {
                throw new Error("Map is not valid!");
            }

            let tilesetUrl = "./assets//" + map.tilesets[0].source;
            this._getData(tilesetUrl, ((data) => {
                let tileset = JSON.parse(data);

                if (tileset.type !== "tileset") {
                    throw new Error("Tileset is not valid!");
                }

                let tilesetImage = new Image();
                tilesetImage.src = "../assets/tilesets/" + tileset.image;
                console.log(tilesetImage.src)
                tilesetImage.onload = onload;

                let tileLayers = [];

                let solidMap = [];
                for (let x = 0; x < map.width; x++) {
                    solidMap[x] = [];
                    for (let y = 0; y < map.height; y++) {
                        solidMap[x][y] = 0;
                    }
                }

                let objects = [];

                map.layers.forEach((_layer) => {
                    if (_layer.type === "tilelayer") {
                        let layer = [];
                        for (let x = 0; x < map.width; x++) {
                            layer[x] = [];
                            for (let y = 0; y < map.height; y++) {
                                layer[x][y] = _layer.data[x + y * map.width];
                            }
                        }
                        tileLayers.push(layer);
                    } else if (_layer.type === "objectgroup") {
                        if (_layer.name === "solids") {
                            _layer.objects.forEach((object) => {
                                let _x = Math.round(object.x / map.tilewidth);
                                let _y = Math.round(object.y / map.tileheight);
                                let width = Math.round(object.width / map.tilewidth);
                                let height = Math.round(object.height / map.tileheight);
                                if (_x >= 0 && _y >= 0) {
                                    for (let x = 0; x < width; x++) {
                                        for (let y = 0; y < height; y++) {
                                            solidMap[_x + x][_y + y] = 1;
                                        }
                                    }
                                }
                            }, this);
                        } else if (_layer.name === "objects") {
                            _layer.objects.forEach((object) => {
                                objects.push({
                                    name: object.name,
                                    position: new Vector(object.x, object.y),
                                    width: object.width,
                                    height: object.height
                                });
                            });
                            this.frontLayerIndex = tileLayers.push("objects");
                        }
                    }
                }, this);

                this.width = map.width;
                this.height = map.height;
                this._tileLayers = tileLayers;
                this.tileWidth = map.tilewidth;
                this.tileHeight = map.tileheight;
                this.solidMap = solidMap;
                this.objects = objects;
                this.tileset = {
                    image: tilesetImage,
                    width: tileset.imagewidth / tileset.tilewidth,
                    height: tileset.imageheight / tileset.tileheight
                };
            }).bind(this));

        }).bind(this));

        function onload() {
            handler();
        }
    }

    _getData(url, ready) {
        console.log(url)
        let xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.onreadystatechange = function() {
            if(this.readyState === 4 && this.status !== 404) {
                ready(this.responseText);
            }
        }
        xhr.send();
    }

    renderBackLayers() {
        for (let i = 0; i < this._tileLayers.length; i++) {
            if (this._tileLayers[i] === "objects") return;
            this.renderLayer(i);           
        }
    }

    renderFrontLayers() {
        for(let i = this.frontLayerIndex; i < this._tileLayers.length; i++) {
            this.renderLayer(i);     
        }
    }

    renderLayer(index) {
        this.game.context.save();
        this.game.context.translate(0 - this.game.camera.topLeftX, 0 - this.game.camera.topLeftY);

        const layer = this._tileLayers[index];
        for (let x = 0; x < this.width; x++) {
            for (let y = 0; y < this.height; y++) {
                if (layer[x][y] !== 0) {
                    let tileID = layer[x][y] - 1;
                    let sy = Math.floor(tileID / this.tileset.width);
                    let sx = tileID - sy * this.tileset.width;
                    sx *= this.tileWidth;
                    sy *= this.tileHeight;
                    let _x = x * this.tileWidth;
                    let _y = y * this.tileHeight;
                    this.game.context.drawImage(this.tileset.image, sx, sy, this.tileWidth, this.tileHeight, _x, _y, this.tileWidth, this.tileHeight);
                }
            }
        }

        this.game.context.restore();
    }

    render() {
        this.renderBackLayers();
        this.renderFrontLayers();
    }

    drawSolid() {
        this.game.context.save();
        this.game.context.translate(0 - this.game.camera.topLeftX, 0 - this.game.camera.topLeftY);

        for (let x = 0; x < this.width; x++) {
            for (let y = 0; y < this.height; y++) {
                if (this.solidMap[x][y]) {
                    this.game.context.fillStyle = "rgba(255,0,0,0.5)";
                    this.game.context.fillRect(x * this.tileWidth, y * this.tileHeight, this.tileWidth, this.tileHeight);
                }
            }
        }

        this.game.context.restore();
    }

    drawGrid() {
        this.game.context.save();
        this.game.context.translate(0 - this.game.camera.topLeftX, 0 - this.game.camera.topLeftY);

        this.game.context.beginPath();
        for (let x = 0; x < this.width + 1; x++) {
            this.game.context.moveTo(x * this.tileWidth, 0);
            this.game.context.lineTo(x * this.tileWidth, this.height * this.tileHeight);
        }
        for (let y = 0; y < this.height + 1; y++) {
            this.game.context.moveTo(0, y * this.tileHeight);
            this.game.context.lineTo(this.width * this.tileWidth, y * this.tileHeight);
        }
        this.game.context.strokeStyle = "white";
        this.game.context.stroke();

        this.game.context.restore();
    }

    drawRect(pos) {
        this.game.context.save();
        this.game.context.translate(0 - this.game.camera.topLeftX, 0 - this.game.camera.topLeftY);
        this.game.context.fillStyle = "rgba(0,0,255,0.5)";
        this.game.context.fillRect(pos.x * this.tileWidth, pos.y * this.tileHeight, this.tileWidth, this.tileHeight);
        this.game.context.restore();
    }

    toTilePosition(position) {
        let tilePos = new Vector(0, 0);
        tilePos.x = Math.floor(position.x / this.tileWidth);
        tilePos.y = Math.floor(position.y / this.tileHeight);
        return tilePos;
    }
}