class Keyboard {
    constructor(game) {
        this.game = game;
        this._map = [];

        document.onkeydown = (e) => {
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            this._map[e.keyCode] = true;
        }

        document.onkeyup = (e) => {
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            this._map[e.keyCode] = false;
        }
    }

    pressed(keyCode) {
        if (this._map[keyCode]) return true;
        return false;
    }
}