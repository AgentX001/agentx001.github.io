class GameObject {
    constructor(game, scene, parameters) {
        this.game = game;
        this.scene = scene;

        this.id = 0;

        this.sprite = null;
        this.spriteAnimationSpeed = 0;
        this.spriteAnimation = "";
        this.spriteFrame = 0;
        this.spriteFrameTime = 0;

        this.position = new Vector(0, 0);

        for (let key in parameters) {
            this[key] = parameters[key];
        }

        this.create();
    }

    setSprite(name) {
        this.sprite = this.game.assetManager.getSprite(name);
    }
    
    spriteAnimationStart() {
        this.spriteAnimationSpeed = this.sprite.animationSpeed;
    }

    spriteAnimationStop(frame) { 
        this.spriteAnimationSpeed = 0;
        this.spriteFrame = frame;
    }
    
    setSpriteAnimation(name) {
        this.spriteAnimation = name;
    }

    setSpriteAnimationFrame(frame) {
        this.spriteFrame = frame;
    }

    create() {}

    _render(delta) {
        if (this.sprite instanceof Sprite && this.spriteAnimation !== "") {
            this.sprite.render(this.position, this.spriteAnimation, this.spriteFrame);
            this.spriteFrameTime += delta;
            if (this.spriteFrameTime >= this.spriteAnimationSpeed && this.spriteAnimationSpeed > 0) {
                this.spriteFrameTime = 0;
                this.spriteFrame++;
                this.spriteFrame = (this.spriteFrame < this.sprite.animations[this.spriteAnimation].length) ? this.spriteFrame : 0;
            }
        }
        this.render(delta);    
    }
    
    render() {}

    destroy() {}
}