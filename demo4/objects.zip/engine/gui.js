class GUI {
    constructor(game) {
        this.game = game;
        this.blocks = [];
    }

    _CSSLoad(name) {
        let link = document.createElement("link");
        link.setAttribute("rel", "stylesheet");
        link.setAttribute("type", "text/css");
        link.setAttribute("href", "./assets/gui/css/" + path);
        document.getElementsByTagName("head")[0].appendChild(link);
    }

    addBlock(name) {
        let container = document.createElement("div");
        document.body.appendChild(container);

        let rect = this.game.canvas.getBoundingClientRect();

        container.style = "position: absolute; user-select: none; display: none;";
        container.style.left = rect.left + "px";
        container.style.top = rect.top + "px";
        container.style.width = this.game.canvas.width + "px";
        container.style.height = this.game.canvas.height + "px";

        this._getData("./assets/gui/" + name + ".html", (data) => {
            container.innerHTML = data;
        });

        this.blocks[name] = container;
    }

    showBlock(name) {
        this.blocks[name].style.display = "block";
    }

    hideBlock(name) {
        this.blocks[name].style.display = "none";
    }

    _getData(url, ready) {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.onreadystatechange = function() {
            if(this.readyState === 4 && this.status !== 404) {
                ready(this.responseText);
            }
        }
        xhr.send();
    }
}